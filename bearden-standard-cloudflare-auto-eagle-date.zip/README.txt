THE BEARDEN STANDARD — LANDING PAGE
===================================
A responsive, static website ready to upload to Cloudflare Pages, Netlify, or other free static hosting. It uses your saved Bearden Standard brand logo and saved Chicago Eagle emblem.

FILES
  index.html               Main webpage
  styles.css               Styling and mobile layout
  script.js                Automatically displays next first Sunday
  assets/                  Bearden Standard, Chicago Eagle, Denmark College logos, and favicon
  first-sunday-chicago-eagle.ics   Optional recurring calendar event

PREVIEW
  Open index.html in a browser. All core content works without a server.

PUBLISH ON CLOUDFLARE PAGES
  1. Go to https://dash.cloudflare.com/ and sign in.
  2. Open Workers & Pages > Create > Pages > Direct Upload.
  3. Upload the entire bearden-standard-landing-page-unified.zip archive or its extracted folder.
  4. In the new site's Custom domains section, add your owned domain and follow the DNS setup instructions.

CONTENT INCLUDED
  Denmark College: 214 S Wabash Ave, Chicago, IL 60604.
  Chandler's actual school attendance schedule (provided by Chandler):
    Monday:    8 AM–5 PM
    Tuesday:   8 AM–5 PM
    Wednesday: 8 AM–2 PM
    Thursday:  8 AM–3 PM
    Friday:    8 AM–2 PM
    Saturday/Sunday: no school listed.
  The separate work shifts from the schedule are NOT published here, because the page is focused on barbering.
  Chicago Eagle: 4713 N Broadway, Chicago, IL 60640.
  Event: first Sunday of every month, 2-6 PM Chicago time, as supplied.
  Instagram: @thebeardenstandard and @sneakerpunkchi.

UPDATES
  Change addresses, hours, or Instagram usernames in index.html.
  Change red/black shades in styles.css (top of the file).
  The next first Sunday date updates automatically using Chicago time.
  Venue/event hours can change; verify before promoting dates.

All source image assets are from the user's saved promotional files and the Denmark College logo the user supplied for this update.

TYPOGRAPHY UPDATE
  Section titles share one font size and weight. The school and Chicago Eagle card titles, labels, body text, key details, and buttons use a shared responsive type scale.
