/* Chicago Eagle: first Sunday monthly, 2–6 PM Chicago local time.
   Uses America/Chicago so it handles daylight saving automatically.
   Updates after the event ends, on each minute, and when a tab is reopened. */
(() => {
  'use strict';
  const target = document.getElementById('next-eagle-date');
  if (!target) return;

  const chicagoClock = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Chicago',
    year: 'numeric', month: 'numeric', day: 'numeric',
    hour: 'numeric', hourCycle: 'h23'
  });
  const displayDate = new Intl.DateTimeFormat('en-US', {
    timeZone: 'UTC', weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'
  });

  function firstSundayOf(year, month) {
    // month is 1–12; UTC arithmetic prevents daylight-saving date shifts.
    const first = new Date(Date.UTC(year, month - 1, 1));
    const day = 1 + (7 - first.getUTCDay()) % 7;
    return new Date(Date.UTC(year, month - 1, day));
  }

  function refreshNextEvent() {
    const parts = Object.fromEntries(chicagoClock.formatToParts(new Date())
      .filter(part => part.type !== 'literal')
      .map(part => [part.type, Number(part.value)]));
    const { year, month, day, hour } = parts;

    let event = firstSundayOf(year, month);
    const eventDay = event.getUTCDate();
    // Keep today's event listed until it finishes at 6 PM Chicago time.
    if (day > eventDay || (day === eventDay && hour >= 18)) {
      event = firstSundayOf(year, month + 1);
    }

    const label = displayDate.format(event);
    if (target.textContent !== label) target.textContent = label;
    // Machine-readable date for calendars/accessibility.
    if (target.tagName === 'TIME') target.dateTime = event.toISOString().slice(0, 10);
  }

  refreshNextEvent();
  setInterval(refreshNextEvent, 60_000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshNextEvent();
  });
})();
